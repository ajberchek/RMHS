In order to run the code, unzip the RMHS.zip file, and go into the unzipped "RMHS" Directory, then into the "DBProject" Directory. 

Then make sure bcrypt and django python packages are installed by running "sudo pip install bcrypt" and "sudo pip install django"

After that, enter "python manage.py runserver" and if you open your browser and navigate to "http://127.0.0.1:8000" then you will be able to interact with the website.

The database file is the RMHS.db file

The presentation file is the Presentation.pdf file
